'use strict';
const canvas=document.querySelector('canvas'),ctx=canvas.getContext('2d'),hint=document.querySelector('#hint'),undo=document.querySelector('#undo'),hour=document.querySelector('#hour');
const TAU=Math.PI*2, tiles=[],cells=new Map(),key=(x,z)=>x+','+z;
function noise(x,z,k=0){let n=Math.sin(x*123.73+z*317.19+k*72.11)*43758.549;return n-Math.floor(n)}
function land(x,z){let a=Math.atan2(z/5,x/7);return (1-Math.hypot(x/7,z/5)+.11*Math.sin(a*3+.6)+.065*Math.cos(a*5))}
function height(x,z){let d=land(x,z);return Math.max(.04,Math.min(1,d*5))*(.25+1.9*Math.max(0,d)+.63*Math.exp(-((x+2)**2+(z+1)**2)/7)+.17*Math.sin(x*.9+z*.6))}
function vertex(x,z){let a=x+(noise(x,z)-.5)*.42,b=z+(noise(x,z,1)-.5)*.42;return [a,b,height(a,b)]}
for(let z=-6;z<=6;z++)for(let x=-8;x<=8;x++)if(land(x,z)>.015){let v=[vertex(x-.5,z-.5),vertex(x+.5,z-.5),vertex(x+.5,z+.5),vertex(x-.5,z+.5)];let t={x,z,v,id:key(x,z),h:height(x,z),seed:noise(x,z)};tiles.push(t);cells.set(t.id,t)}
let W,H,S,ox,oy,bg,tool='house',history=[],objects=new Map(),stroke=null,preview=[],hover=null,born=new Map(),frame=0,clock=0,kcursor=null;
const alterations=new Map(), houses=new Map(), doorways=new Map();
let scenery=[],orderedHouses=[];
function validAction(p){
  if(!p||typeof p.id!=='string')return false;
  if(p.type==='block')return [p.x,p.z,p.h].every(Number.isFinite)&&Number.isInteger(p.level)&&p.level>=0;
  if(p.type==='house')return cells.has(p.id)||(p.id.startsWith('house:')&&[p.x,p.z,p.h].every(Number.isFinite));
  if(p.type==='widen')return [-1,1].includes(p.side);
  if(p.type==='storey')return true;
  return cells.has(p.id)&&['tree','path'].includes(p.type);
}
const saveKey='cala-town-v1';try{let s=JSON.parse(localStorage.getItem(saveKey)||'null');if(s){history=(Array.isArray(s.history)?s.history:[]).map(g=>Array.isArray(g)?g.filter(validAction):[]).filter(g=>g.length);hour.value=s.light??20}}catch{}
function save(){try{localStorage.setItem(saveKey,JSON.stringify({history,light:+hour.value}))}catch{hint.textContent='Device storage unavailable this session'}}
function P(x,z,h=0){return [ox+S*(x+.21*z),oy+S*(.52*z-h)]}
function poly(g,pts,color){g.fillStyle=color;g.beginPath();pts.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.fill()}
function line(g,x,y,X,Y,c,w){g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(x,y);g.lineTo(X,Y);g.stroke()}
function oval(g,x,y,rx,ry,c){g.fillStyle=c;g.beginPath();g.ellipse(x,y,Math.abs(rx),Math.abs(ry),0,0,TAU);g.fill()}
function mix(a,b,f){let rgb=[1,3,5].map(i=>Math.round(parseInt(a.slice(i,i+2),16)*(1-f)+parseInt(b.slice(i,i+2),16)*f));return 'rgb('+rgb+')'}
const coast=tiles.flatMap(t=>t.v.flatMap((v,i)=>{let [dx,dz]=[[0,-1],[1,0],[0,1],[-1,0]][i];return cells.has(key(t.x+dx,t.z+dz))?[]:[[v,t.v[(i+1)%4],i]]}));
// Round exposed corners while keeping the buildable surface and its hit areas aligned.
const rim=new Map(), vertexKey=v=>v[0]+','+v[1];
for(const [a,b] of coast){for(const [v,n] of [[a,b],[b,a]]){let k=vertexKey(v);if(!rim.has(k))rim.set(k,[]);rim.get(k).push(n)}}
const softened=new Map();
for(const t of tiles)for(const v of t.v){const k=vertexKey(v),ns=rim.get(k);if(ns&&!softened.has(k)){const x=v[0]*.48+ns.reduce((a,n)=>a+n[0],0)*.52/ns.length,z=v[1]*.48+ns.reduce((a,n)=>a+n[1],0)*.52/ns.length;softened.set(k,[x,z,.13+.14*noise(x,z)])}}
for(const t of tiles)for(const v of t.v){const r=softened.get(vertexKey(v));if(r)v.splice(0,3,...r)}
function backdrop(){const lanes=joinedLanes(objects);bg=document.createElement('canvas');const density=Math.min(4,Math.max(canvas.width/W,1600/W),Math.sqrt(4500000/(W*H)));bg.width=Math.round(W*density);bg.height=Math.round(H*density);let g=bg.getContext('2d');g.scale(bg.width/W,bg.height/H);let dusk=+hour.value/100,horizon=H*.245,grad=g.createLinearGradient(0,0,0,horizon);grad.addColorStop(0,mix('#a9d6d8','#d69da5',dusk));grad.addColorStop(1,mix('#f8ebcb','#ffce98',dusk));g.fillStyle=grad;g.fillRect(0,0,W,horizon+1);
oval(g,W*(.79-.48*dusk),H*(.11+.11*dusk),H*.027,H*.027,'#fff2cacc');
for(let j=0;j<2;j++){let pts=[[0,horizon+1]];for(let i=0;i<=100;i++){let a=i/100;pts.push([a*W,horizon-H*(.018+.032*Math.sin(a*9+j*4)+.015*Math.sin(a*18+2*j)+.009*noise(i>>1,j))])}pts.push([W,horizon+2]);poly(g,pts,j?'#92afad':'#b4c5bb')}
grad=g.createLinearGradient(0,horizon,0,H);grad.addColorStop(0,mix('#86bfc0','#bbaf9c',dusk));grad.addColorStop(.45,mix('#388e99','#6d9292',dusk));grad.addColorStop(1,mix('#17586b','#415f72',dusk));g.fillStyle=grad;g.fillRect(0,horizon,W,H);
for(let i=0;i<1850;i++){let x=noise(i,8)*W,r=noise(i,9),y=horizon+(H-horizon)*r;line(g,x,y,x+1+noise(i,10)*W*.018*(.2+r),y-.3,'rgba(214,242,222,'+(.08+.16*noise(i,11))+')',.5+r*.7)}
if(art['campanian-bay']){
  const plate=art['campanian-bay'],sw=Math.min(plate.width,plate.height*W/H),sx=(plate.width-sw)*.50,split=plate.height*.375;
  g.drawImage(plate,sx,0,sw,split,0,0,W,horizon);
  g.drawImage(plate,sx,split,sw,plate.height-split,0,horizon,W,H-horizon);
  if(dusk>.2){g.fillStyle='rgba(137,82,92,'+((dusk-.2)*.18)+')';g.fillRect(0,0,W,H)}
  if(dusk<.4){g.fillStyle='rgba(179,197,199,'+(.12*(1-dusk/.4))+')';g.fillRect(0,0,W,H)}
}
for(let i=0;i<3;i++){let x=W*[.15,.86,.69][i],y=H*[.32,.415,.28][i],a=Math.min(W,H)*[.018,.026,.009][i];line(g,x,y,x,y-a*1.05,'#675a45',Math.max(.6,a*.052));line(g,x-a*.49,y-a*.9,x+a*.51,y-a*.81,'#796449',Math.max(.6,a*.045));
poly(g,[[x-a*.46,y-a*.86],[x+a*.48,y-a*.78],[x+a*.35,y-a*.25],[x-a*.32,y-a*.31]],'#e7d7ae');
poly(g,[[x-a*.55,y-1],[x+a*.57,y-2],[x+a*.33,y+3],[x-a*.26,y+3]],'#6a5946')}

if(art.headland){
  const xs=[],ys=[];
  for(const t of tiles)for(const [x,z,h] of t.v){
    const top=P(x,z,h),foot=P(x,z,-.14);xs.push(top[0]);ys.push(top[1],foot[1]);
  }
  const left=Math.min(...xs),top=Math.min(...ys);
  g.drawImage(art.headland,left,top,Math.max(...xs)-left,Math.max(...ys)-top);
  for(const t of tiles)paintLane(g,t,lanes);
}else{
g.lineCap='round';for(let [a,b] of coast){let A=P(a[0],a[1]),B=P(b[0],b[1]);line(g,...A,...B,'#86bab1',S*.23);line(g,...A,...B,'#dce4cc',S*.054)}
for(let t of tiles){let pts=t.v.map(v=>P(...v));for(let i of [1,2,3]){let [dx,dz]=[[0,-1],[1,0],[0,1],[-1,0]][i];if(cells.has(key(t.x+dx,t.z+dz)))continue;let a=t.v[i],b=t.v[(i+1)%4],base=[P(b[0],b[1],-.14),P(a[0],a[1],-.14)];poly(g,[pts[i],pts[(i+1)%4],...base],i===2?'#bcaa8e':'#968e7d');paintedPlane(g,'limestone',[pts[i],pts[(i+1)%4],...base],.84)}
let slope=height(t.x+.5,t.z)-height(t.x-.5,t.z),q=Math.min(1,Math.max(0,.4+slope*.65+t.seed*.23));let c=land(t.x,t.z)<.19?mix('#bcae87','#e2d0a2',q):mix('#8d9d70','#cbd09a',q);poly(g,pts,c);g.strokeStyle=c;g.lineWidth=.75;g.stroke();
terrainPaint(g,t,pts,S);
for(let j=0;j<9;j++){let u=noise(t.x,t.z,j+2),v=noise(t.z,t.x,j+33);let [x,y]=[0,1].map(i=>(1-v)*(pts[0][i]*(1-u)+pts[1][i]*u)+v*(pts[3][i]*(1-u)+pts[2][i]*u));line(g,x,y,x+S*.055,y-S*.016,j%3?'#75805e38':'#fff4c064',Math.max(.65,S*.023))}
paintLane(g,t,lanes);
}
paintTerraces(g);
}
let dock=tiles.find(t=>t.z===4&&t.x===0)||tiles[tiles.length-2];let [x,y]=P(dock.x,dock.z,dock.h);g.save();g.translate(x,y);g.scale(S,S);poly(g,[[-.32,0],[.13,-.06],[.47,1.05],[.03,1.15]],'#8e7256');for(let i=0;i<12;i++){
  const v=i*.089,dx=v*.33;
  const corners=[[dx-.32,v],[dx+.13,v-.065],[dx+.15,v+.011],[dx-.30,v+.079]];
  poly(g,corners,mix('#856643','#bb9767',noise(i,9)));
  for(let j=0;j<4;j++){const f=j*.017;line(g,dx-.29,v+f+.008,dx+.11,v+f-.048,j%2?'#d1ad7d66':'#6d533d88',.006)}
  line(g,...corners[0],...corners[1],'#dbb88a',.01);
}for(let a of [0,.94])line(g,a*.33+.10,a+.08,a*.33+.10,a-.19,'#654f3e',.07);amphora(g,-.27,.08,.26);amphora(g,-.40,.05,.21);g.restore();
}
function resize(){resetCamera();W=canvas.clientWidth;H=canvas.clientHeight;let d=Math.min(devicePixelRatio||1,2);canvas.width=W*d;canvas.height=H*d;S=Math.min(W/16.5,H/11.8,78);ox=W*.50;oy=H*.55+S*.4;ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);backdrop();draw()}
function tree(g,t){const olive=t.seed<.36||t.seed>.967,img=art[olive?'olive':'cypress'];
if(img){const h=(olive?1.00:1.58)*(.84+.28*t.seed),w=h*img.width/img.height;g.drawImage(img,-w*.49,-h,w,h);return}
let tall=.92+t.seed*.53;line(g,0,0,0,-tall*.78,'#705e43',.07);for(let k=0;k<3;k++){let x=(k-1)*.12,y=-.34-Math.abs(k-1)*-.05,h=tall*(k===1?1:.68);poly(g,[[x-.10,y],[x-.14,y-h*.28],[x-.08,y-h*.73],[x+.015,y-h],[x+.105,y-h*.64],[x+.13,y-h*.25],[x+.08,y]],['#405f47','#355842','#55754e'][k]);poly(g,[[x-.1,y-h*.15],[x-.075,y-h*.7],[x+.013,y-h*.98],[x+.018,y-h*.45]],'#6e8858')}}
function roofPoint(u,v,h){
  return [-.435+.61*u+.393*v,-h-.015+.13*u-.25*v];
}
function roofPanel(g,outer,inner,col,n){
  poly(g,[outer[0],outer[1],inner[1],inner[0]],col);
  paintedPlane(g,'tiles',[inner[0],inner[1],outer[1],outer[0]],.90);
  for(let i=0;i<n;i++){
    const f=(i+.45)/n;
    const sample=pair=>pair[0].map((p,j)=>p+(pair[1][j]-p)*f);
    const a=sample(outer),b=sample(inner);
    line(g,...a,...b,'#773c2c45',.007);line(g,a[0]+.006,a[1],b[0]+.006,b[1],'#d7946499',.005);
  }
}
function amphora(g,x,y,size){
  g.save();g.translate(x,y);g.scale(size,size);
  for(const s of [-1,1]){g.beginPath();g.ellipse(.25*s,-.64,.12,.19,0,0,TAU);g.lineWidth=.065;g.strokeStyle='#90583a';g.stroke()}
  poly(g,[[-.14,-.98],[.14,-.98],[.12,-.77],[.28,-.62],[.25,-.37],[.04,0],[-.06,0],[-.27,-.42],[-.27,-.63],[-.12,-.78]],'#bd784b');
  line(g,-.08,-.88,-.15,-.49,'#e8b37e',.045);line(g,-.16,-.98,.16,-.98,'#875034',.08);g.restore();
}
function laneSurface(tile,u,v){
  const [a,b,c,d]=tile.v;
  return a.map((value,i)=>(1-v)*(value*(1-u)+b[i]*u)+v*(d[i]*(1-u)+c[i]*u));
}
function joinedLanes(placed){
  const layout=new Map(placed);for(const id of doorways.keys())if(!layout.has(id))layout.set(id,'house');
  for(const [id,kind] of placed){
    if(kind!=='path')continue;
    const t=cells.get(id);
    for(const dz of [-1,1]){
      const end=cells.get(key(t.x+1,t.z+dz));
      if(!end||placed.get(end.id)!=='path')continue;
      const bends=[cells.get(key(t.x+1,t.z)),cells.get(key(t.x,t.z+dz))].filter(Boolean);
      if(bends.some(b=>layout.has(b.id)))continue;
      // Carry the width through a diagonal turn using the gentler open shoulder.
      const midHeight=(t.h+end.h)/2;
      bends.sort((a,b)=>Math.abs(a.h-midHeight)-Math.abs(b.h-midHeight));
      if(bends.length)layout.set(bends[0].id,'path');
    }
  }
  return layout;
}
function paintLane(g,t,layout){
  const kind=layout.get(t.id);
  if(kind!=='path'&&kind!=='house')return;
  const ports=[];
  function neighbour(dx,dz){return layout.get(key(t.x+dx,t.z+dz))}
  for(const [dx,dz] of [[0,-1],[1,0],[0,1],[-1,0],[1,1],[-1,1],[1,-1],[-1,-1]]){
    const adjacent=neighbour(dx,dz);
    if(adjacent!=='path'&&(kind!=='path'||adjacent!=='house'))continue;
    if(dx&&dz&&(kind==='house'||adjacent==='house'||neighbour(dx,0)||neighbour(0,dz)))continue;
    ports.push([.5+dx*.5,.5+dz*.5]);
  }
  if(kind==='house'&&!ports.length)return;
  const center=kind==='house'?[.5,.5]:[.5+(t.seed-.5)*.19,.5+(noise(t.x,t.z,9)-.5)*.17];
  // Turn through the inside of a bend in one curve. Forks share a worn centre.
  let curves;
  if(ports.length===2&&kind==='path')curves=[[ports[0],center,ports[1]]];
  else if(ports.length)curves=ports.map(p=>[p,[p[0]*.4+center[0]*.6,p[1]*.4+center[1]*.6],center]);
  else curves=[[[center[0]-.16,center[1]+.045],center,[center[0]+.17,center[1]-.035]]];
  const beach=land(t.x,t.z)<.19;
  const corners=t.v.map(v=>P(...v));
  g.save();g.beginPath();corners.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.clip();
  function point(u,v){return P(...laneSurface(t,u,v))}
  for(const [start,control,end] of curves){
    const rows=[];
    for(let i=0;i<=16;i++){
      const f=i/16,r=1-f;
      const u=r*r*start[0]+2*r*f*control[0]+f*f*end[0],v=r*r*start[1]+2*r*f*control[1]+f*f*end[1];
      const du=r*(control[0]-start[0])+f*(end[0]-control[0]),dv=r*(control[1]-start[1])+f*(end[1]-control[1]);
      const length=Math.hypot(du,dv)||1;
      const earth=laneSurface(t,u,v);
      const width=.125+Math.sin(earth[0]*7+earth[2])* .012+Math.sin(earth[1]*12)*.006;
      let taper=ports.length?1:.16+.84*Math.sin(Math.PI*f);
      if(ports.length===1&&kind==='path')taper=Math.min(1,Math.sqrt(1-f)*2.8);
      // The building is anchored at its surveyed elevation. Blend the last
      // stretch up to its doorstep even where the ground dips below it.
      const home=doorways.get(t.id);
      const doorstep=kind==='house'&&home?P(home.x,home.z,home.h):null;
      const endGround=doorstep?point(...center):null;
      const edge=k=>{
        const p=point(u-dv/length*width*k*taper,v+du/length*width*k*taper);
        if(doorstep){
          const sideDoor=neighbour(1,0)==='path';
          p[0]+=(doorstep[0]+S*(sideDoor?.32:-.095)-endGround[0])*f*f;
          p[1]+=(doorstep[1]-S*.025-endGround[1])*f*f;
        }
        return p;
      };
      rows.push({edge,earth});
    }
    function ribbon(width,color){
      const left=rows.map(r=>r.edge(-width)),right=rows.map(r=>r.edge(width)).reverse();
      poly(g,left.concat(right),color);
    }
    ribbon(1.35,beach?'#ab99793d':'#75674458');
    ribbon(1.06,beach?'#b9a37d':'#a89168');
    ribbon(.76,beach?'#c3ac82':'#b69b70');
    if(art.plaster){
      const outline=rows.map(r=>r.edge(-1)).concat(rows.map(r=>r.edge(1)).reverse());
      const xs=outline.map(p=>p[0]),ys=outline.map(p=>p[1]),minX=Math.min(...xs),minY=Math.min(...ys);
      g.save();g.beginPath();outline.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.clip();
      g.globalAlpha*=.58;g.drawImage(art.plaster,minX,minY,Math.max(.1,Math.max(...xs)-minX),Math.max(.1,Math.max(...ys)-minY));g.restore();
    }
    for(let i=2;i<16;i+=3){
      const row=rows[i],prev=rows[i-2].earth,next=rows[i+1].earth;
      const grade=Math.abs(next[2]-prev[2])/Math.max(.001,Math.hypot(next[0]-prev[0],next[1]-prev[1]));
      const grit=noise(t.x,t.z,i);
      if(grade>.32&&i%2===0){
        const a=row.edge(-.84+grit*.14),b=row.edge(.68+grit*.17);
        line(g,...a,...b,'#958a709c',S*.028);
        line(g,a[0],a[1]-S*.014,b[0],b[1]-S*.014,'#e0cfaa',S*.018);
      }else{
        const [x,y]=row.edge(grit*1.5-.75);
        line(g,x,y,x+S*.033,y-S*.005,'#9c8f7377',S*.012);
      }
      const [x,y]=row.edge((i%2?1:-1)*(1.02+grit*.16));
      line(g,x,y,x+S*.026,y-S*.011,beach?'#decea4':'#a4aa7c',S*.018);
    }
  }
  g.restore();
}
function draw(now=performance.now()){blockFaces=[];ctx.save();ctx.fillStyle=mix('#a8d6d6','#d4a2a2',+hour.value/100);ctx.fillRect(0,0,W,H);ctx.translate(camera.x,camera.y);ctx.scale(camera.zoom,camera.zoom);const marginX=-camera.x/camera.zoom,marginY=-camera.y/camera.zoom;
if(marginX<0)ctx.drawImage(bg,0,0,1,bg.height,marginX,0,-marginX,H);
if(marginX+W/camera.zoom>W)ctx.drawImage(bg,bg.width-1,0,1,bg.height,W,0,marginX+W/camera.zoom-W,H);
if(marginY+H/camera.zoom>H){ctx.fillStyle=mix('#17586b','#415f72',+hour.value/100);ctx.fillRect(marginX,H,W/camera.zoom,marginY+H/camera.zoom-H)}
ctx.drawImage(bg,0,0,W,H);let anim=false;
const proposed=tool==='path'?(preview.length?preview:(!stroke&&hover&&!objects.has(hover.id)?[hover]:[])):[];
if(proposed.length){
  const proposedMap=new Map(objects);for(const t of proposed)proposedMap.set(t.id,'path');
  const layout=joinedLanes(proposedMap);
  ctx.save();ctx.globalAlpha=.72;
  for(const t of tiles)if(proposed.some(p=>Math.abs(t.x-p.x)<=1&&Math.abs(t.z-p.z)<=1))paintLane(ctx,t,layout);
  ctx.restore();
}
const scene=preview[0]?.free?scenery.concat({t:preview[0],building:true}):scenery;
// Cast broad shadows from the actual footprint before drawing any walls.
for(const t of orderedHouses){
  const {width,offset,h,base}=houseShape(t),[x,y]=P(t.x,t.z,t.h);
  const foot=[[-.39,.02],[.17,.14],[.54,-.07],[-.03,-.20]].map(([u,v])=>[x+(offset+width*u)*S,y+v*S]);
  const dx=(h+base)*S*(.63+.63*hour.value/100),dy=(h+base)*S*.20;
  const shadow=[foot[0],foot[1],[foot[1][0]+dx,foot[1][1]+dy],[foot[2][0]+dx,foot[2][1]+dy],[foot[3][0]+dx,foot[3][1]+dy],foot[3]];
  poly(ctx,shadow,'rgba(68,52,39,.24)');
  poly(ctx,foot.map(([u,v])=>[u+S*.026,v+S*.03]),'rgba(57,42,31,.33)');
}
const pendingSpaces=typeof romanSpaces==='undefined'?[]:romanSpaces.slice().sort((a,b)=>spaceDepth(a)-spaceDepth(b));
let spaceCursor=0;
for(let {t,building} of scene){
  while(spaceCursor<pendingSpaces.length&&t.z>=spaceDepth(pendingSpaces[spaceCursor]))drawRomanSpaces(ctx,[pendingSpaces[spaceCursor++]]);let type=building?'house':objects.get(t.id);if(!building&&doorways.has(t.id)&&type!=='path')continue;if(!type&&t.seed>.915&&land(t.x,t.z)>.22)type='wild';let ghost=!exploring&&(preview.includes(t)||(!stroke&&hover===t&&!type&&tool!=='house'));if(!type&&!ghost)continue;let [x,y]=P(t.x,t.z,t.h);ctx.save();ctx.translate(x,y);ctx.scale(S,S);if(ghost&&!objects.has(t.id)){ctx.globalAlpha=.55;type=tool}if(type==='path'){ctx.restore();continue}if(type!=='house'){let l=+hour.value/100;poly(ctx,[[-.18,0],[.18,.05],[.48+l*.7,.20+l*.17],[.36+l*.6,.25+l*.16]],'#435c4a43')}
let age=now-(born.get(t.id)??-1e6);if(age<400&&age>=0){anim=true;let p=age/400;ctx.scale(1,1-(1-p)**3+.1*Math.sin(p*Math.PI*2)*(1-p))}
if(type==='house')house(ctx,t);else{if(type==='wild')ctx.scale(.73,.73);tree(ctx,t)}ctx.restore()}
while(spaceCursor<pendingSpaces.length)drawRomanSpaces(ctx,[pendingSpaces[spaceCursor++]]);
if(+hour.value>20){ctx.fillStyle='rgba(240,141,69,'+((+hour.value-20)*.00165)+')';ctx.fillRect(0,0,W,H)}
ctx.fillStyle='rgba(244,224,188,.06)';ctx.fillRect(0,0,W,H);
ctx.fillStyle='rgba(68,95,86,.025)';ctx.fillRect(0,0,W,H);
ctx.restore();if(anim&&!frame)frame=requestAnimationFrame(n=>{frame=0;draw(n)})}
function pick(x,y){for(let i=tiles.length-1;i>=0;i--){let t=tiles[i],pts=t.v.map(v=>P(...v)),inside=false;for(let a=0,b=3;a<4;b=a++){let A=pts[a],B=pts[b];if((A[1]>y)!==(B[1]>y)&&x<(B[0]-A[0])*(y-A[1])/(B[1]-A[1])+A[0])inside=!inside}if(inside)return t}return null}
let audio;function chime(){try{audio??=new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume().catch(()=>{});let o=audio.createOscillator(),v=audio.createGain(),n=audio.currentTime;o.type='sine';o.frequency.value=[330,392,440,523,587][history.length%5];v.gain.setValueAtTime(.045,n);v.gain.exponentialRampToValueAtTime(.0001,n+.33);o.connect(v).connect(audio.destination);o.start();o.stop(n+.34)}catch{}}
const hints={house:'Tap to build · roofs and spaces grow together',path:'Trace a path between buildings',tree:'Tap to plant · drag for a grove'};
function insideFace(x,y,points){
  let inside=false;
  for(let i=0,j=points.length-1;i<points.length;j=i++){
    const [a,b]=points[i],[c,d]=points[j];
    if((b>y)!==(d>y)&&x<(c-a)*(y-b)/(d-b)+a)inside=!inside;
  }
  return inside;
}
function foundation(px,py){
  const cell=pick(px,py);
  let x,z,h;
  if(cell){
    for(const indices of [[0,1,2],[0,2,3]]){
      const v=indices.map(i=>cell.v[i]),[a,b,c]=v.map(p=>P(...p));
      const det=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
      if(Math.abs(det)<1e-8)continue;
      const u=((b[1]-c[1])*(px-c[0])+(c[0]-b[0])*(py-c[1]))/det;
      const w=((c[1]-a[1])*(px-c[0])+(a[0]-c[0])*(py-c[1]))/det;
      if(Math.min(u,w,1-u-w)<-1e-6)continue;
      [x,z,h]=v[0].map((n,i)=>u*n+w*v[1][i]+(1-u-w)*v[2][i]);break;
    }
  }
  if(x===undefined){
    if(py<H*.245)return null;
    h=0;z=(py-oy)/(.52*S);x=(px-ox)/S-.21*z;
  }
  return {id:'preview',x,z,h,cell:cell?.id,seed:noise(x,z),free:true};
}
function commit(){if(tool==='house'){if(preview.length)placeHouse(preview[0]);else hint.textContent='Choose land or water for the foundation';preview=[];stroke=null;draw();return}let g=preview.filter(t=>!objects.has(t.id)).map(t=>({id:t.id,type:tool}));if(g.length){history.push(g);g.forEach(p=>born.set(p.id,performance.now()));rebuild();hint.textContent=tool==='house'?'Tap a wall to widen · roof for a second floor':hints[tool];chime();save()}else hint.textContent=hover?'That spot is already in use':'Choose a spot on the hillside';preview=[];stroke=null;draw()}
function trace(e){if(stroke.edit){preview=[];hover=null;return}let x=e.clientX,y=e.clientY,prev=stroke.last,steps=Math.max(1,Math.ceil(Math.hypot(x-prev[0],y-prev[1])/(S*.17)));if(tool==='house'){const site=foundation(x,y);preview=site?[{...snappedBlock(site),id:'preview',free:true,seed:site.seed}]:[];hover=null;draw();return}for(let i=1;i<=steps;i++){let t=pick(prev[0]+(x-prev[0])*i/steps,prev[1]+(y-prev[1])*i/steps);if(tool==='house'&&i!==steps)continue;if(t&&!objects.has(t.id)&&!preview.includes(t))preview.push(t)}stroke.last=[x,y];hover=pick(x,y);draw()}
const camera={zoom:1,x:0,y:0};
const contacts=new Map();
let navigating=false, pinch=null, cameraFrame=0;
function resetCamera(){
  camera.zoom=1;camera.x=0;camera.y=0;
  contacts.clear();navigating=false;pinch=null;
  stroke=null;preview=[];hover=null;
}
function worldPoint(e){
  return {clientX:(e.clientX-camera.x)/camera.zoom,clientY:(e.clientY-camera.y)/camera.zoom};
}
function pinchPose(){
  const [a,b]=contacts.values();
  return {x:(a.x+b.x)/2,y:(a.y+b.y)/2,distance:Math.max(1,Math.hypot(b.x-a.x,b.y-a.y))};
}
function anchorPinch(){
  pinch=null;
  if(contacts.size<2)return;
  const pose=pinchPose();
  pinch={zoom:camera.zoom,distance:pose.distance,
    x:(pose.x-camera.x)/camera.zoom,y:(pose.y-camera.y)/camera.zoom};
}
function moveCamera(){
  const pose=pinchPose();
  camera.zoom=Math.max(1,Math.min(4,pinch.zoom*pose.distance/pinch.distance));
  // Keep the touched spot under the midpoint until the view reaches the scene edge.
  let left=0,right=W,top=0,bottom=H;
  for(const t of orderedHouses){
    // Independent blocks can form narrow towers and side extensions.  The
    // old envelope bounds only measured one floor and clipped tall towers.
    if(typeof blockGeometry==='function'){
      const {top:roof,bottom:foot}=blockGeometry(t);
      const [x,y]=P(t.x,t.z,t.h);
      for(const [dx,dy] of [...roof,...foot]){
        left=Math.min(left,x+S*dx-32);
        right=Math.max(right,x+S*dx+32);
        top=Math.min(top,y+S*dy-90);
        bottom=Math.max(bottom,y+S*dy+50);
      }
    }else{
      const m=houseShape(t),[x,y]=P(t.x,t.z,t.h);
      left=Math.min(left,x+S*(m.offset-.45*m.width)-32);
      right=Math.max(right,x+S*(m.offset+.58*m.width)+32);
      top=Math.min(top,y-S*(m.h+m.base+.3)-90);
      bottom=Math.max(bottom,y+50);
    }
  }
  camera.x=Math.max(W-right*camera.zoom,Math.min(-left*camera.zoom,pose.x-pinch.x*camera.zoom));
  camera.y=Math.max(H-bottom*camera.zoom,Math.min(-top*camera.zoom,pose.y-pinch.y*camera.zoom));
  if(!cameraFrame)cameraFrame=requestAnimationFrame(()=>{cameraFrame=0;draw()});
}
let exploring=false, inspected=null, previousView=null;
function leaveDetail(){
  if(previousView)Object.assign(camera,previousView);
  previousView=null;inspected=null;note.hidden=true;
}
const note=document.querySelector('#note'),explore=document.querySelector('#explore');
function setExploring(active){
  leaveDetail();exploring=active;explore.setAttribute('aria-pressed',String(active));note.hidden=true;
  document.querySelectorAll('[data-tool]').forEach(b=>b.setAttribute('aria-pressed',!active&&b.dataset.tool===tool));
  hint.textContent=active?'Tap a house to look inside Roman life':hints[tool];
  preview=[];hover=null;draw();
}
explore.onclick=()=>setExploring(!exploring);
document.querySelector('#dismiss').onclick=()=>{leaveDetail();hint.textContent='Tap another house to explore';draw()};
function inspectHouse(t){
  if(!t){hint.textContent='Choose a house to explore';return}
  const {width,offset,h,base}=houseShape(t);
  const atGround=(t.level||0)===0;
  const beneath=t.level>0&&typeof adjacentBlock==='function'?adjacentBlock(t,0,0,-1):null;
  const [x,y]=P(t.x,t.z,t.h);
  if(!previousView)previousView={...camera};inspected=t;
  camera.zoom=4;
  camera.x=Math.max(-3*W,Math.min(0,W*.5-4*(x+S*offset)));
  camera.y=Math.max(-3*H,Math.min(0,H*.44-4*(y-S*(h*.5+base))));
  // Avoid describing an atrium or a visible jar that the block renderer
  // does not actually contain. Context follows the selected floor.
  const subject=atGround?'ground':beneath?'upper':'extension';
  const details={
    ground:['A Roman doorway','A home entrance connected domestic life to the street. The painted limestone and terracotta here suggest materials common around Roman Campania.'],
    upper:['Rooms above the street','Upper rooms and additional storeys were part of Roman urban building. Cala lets you construct them one footprint at a time.'],
    extension:['An upper extension','This new upper-level space projects beyond the rooms beneath it. It still needs a convincing structural support treatment in Cala.']
  };
  document.querySelector('#feature').textContent=details[subject][0];
  document.querySelector('#detail').textContent=details[subject][1];
  const source=document.querySelector('#source');
  source.textContent='Pompeii Archaeological Park · Roman housing';
  source.href='https://pompeiisites.org/en/pompeii-map/analysis/roman-housing/';
  note.hidden=false;draw();
}
canvas.oncontextmenu=e=>{if(tool==='house'&&!exploring)e.preventDefault()};
canvas.onpointerdown=e=>{
  canvas.setPointerCapture(e.pointerId);
  contacts.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(contacts.size>1||navigating){
    navigating=true;stroke=null;preview=[];hover=null;anchorPinch();draw();return;
  }
  const p=worldPoint(e);
  if(exploring){stroke={id:e.pointerId,inspect:true};return}
  stroke={id:e.pointerId,started:performance.now(),last:[p.clientX,p.clientY],edit:tool==='house'?houseAt(p.clientX,p.clientY):null};trace(p);
};
canvas.onpointermove=e=>{
  if(contacts.has(e.pointerId))contacts.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(navigating){if(pinch)moveCamera();return}
  const p=worldPoint(e);
  if(exploring)return;
  if(stroke?.id===e.pointerId)trace(p);
  else if(!stroke&&e.pointerType==='mouse'){hover=tool==='house'&&houseAt(p.clientX,p.clientY)?null:pick(p.clientX,p.clientY);draw()}
};
function endContact(e){
  if(!contacts.delete(e.pointerId))return;
  if(navigating){
    anchorPinch();navigating=contacts.size>0;return;
  }
  if(e.type==='pointerup'&&stroke?.id===e.pointerId){
    const p=worldPoint(e);
    if(stroke.inspect){inspectHouse(houseAt(p.clientX,p.clientY)?.t)}else if(stroke.edit){
      const hit=houseAt(p.clientX,p.clientY);
      if(hit?.t.id===stroke.edit.t.id&&hit.type===stroke.edit.type)alterHouse(hit);
    }else{trace(p);commit()}
  }
  preview=[];stroke=null;hover=null;draw();
}
canvas.onpointerup=endContact;
canvas.onpointercancel=endContact;
canvas.onlostpointercapture=endContact;
canvas.onpointerleave=()=>{if(!stroke){hover=null;draw()}};
canvas.onkeydown=e=>{let t=kcursor||cells.get('0,0'),dirs={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]};if(dirs[e.key]){e.preventDefault();let [x,z]=dirs[e.key];kcursor=cells.get(key(t.x+x,t.z+z))||t;hover=kcursor;draw()}else if(e.key==='Enter'||e.key===' '){e.preventDefault();if(exploring){inspectHouse(doorways.get(t.id))}else{hover=t;preview=[tool==='house'?{...t,cell:t.id}:t];commit()}}};
document.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{tool=b.dataset.tool;setExploring(false);document.querySelectorAll('[data-tool]').forEach(x=>x.setAttribute('aria-pressed',x===b));hint.textContent=hints[tool];draw()});
undo.onclick=()=>{if(!history.length)return;previousView=null;leaveDetail();history.pop();rebuild();hint.textContent='Last placement undone';save();draw()};
document.querySelector('#sun').onclick=e=>{let l=document.querySelector('#light');l.hidden=!l.hidden;e.currentTarget.setAttribute('aria-expanded',!l.hidden)};hour.oninput=()=>{backdrop();draw()};hour.onchange=save;

