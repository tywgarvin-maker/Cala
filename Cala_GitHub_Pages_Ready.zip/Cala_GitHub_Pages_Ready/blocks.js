// A block has an independent location and one floor of height.
// These two horizontal axes match the oblique architectural drawing.
const blockAxes=[[.64,.23],[.48,-.52]];
const blockHeight=.60;
const blockIndex=new Map();
let blockFaces=[];
const blockKey=(x,z,h)=>[x,z,h].map(v=>Math.round(v*1000)).join(',');
function adjacentBlock(t,du,dv,dy=0){
  return blockIndex.get(blockKey(t.x+du*.64+dv*.48,t.z+du*.23-dv*.52,t.h+dy*blockHeight));
}
function blockOffset(t,du,dv,dy=0){
  return {x:t.x+du*.64+dv*.48,z:t.z+du*.23-dv*.52,h:t.h+dy*blockHeight,
    level:Math.max(0,(t.level||0)+dy),group:t.group||t.id};
}
function registerBlock(item){
  const k=blockKey(item.x,item.z,item.h);
  if(blockIndex.has(k))return;
  const t={...item,seed:noise(item.x,item.z)};
  houses.set(t.id,t);blockIndex.set(k,t);
}
function rebuild(){
  objects.clear();houses.clear();doorways.clear();blockIndex.clear();
  const legacy=new Map();
  for(const group of history)for(const item of group){
    if(item.type==='house'){
      const t=cells.get(item.id)||item;
      legacy.set(item.id,{...t,id:item.id,floors:1,left:0,right:0});
    }else if(item.type==='storey'||item.type==='widen'){
      const t=legacy.get(item.id);if(!t)continue;
      if(item.type==='storey')t.floors++;
      else if(item.side<0)t.left++;else t.right++;
    }
  }
  // Retain each old undo transaction. Every replay subdivides its current
  // rectangular envelope into independently editable blocks.
  for(const t of legacy.values())for(let u=-t.left;u<=t.right;u++)for(let level=0;level<t.floors;level++){
    registerBlock({...blockOffset(t,u,0,level),id:t.id+'@'+u+','+level,group:t.id,level});
  }
  for(const group of history)for(const item of group){
    if(item.type==='block')registerBlock(item);
    if(item.type==='tree'||item.type==='path')objects.set(item.id,item.type);
  }
  orderedHouses=[...houses.values()].sort((a,b)=>a.z-b.z||a.h-b.h||a.x-b.x);
  for(const t of orderedHouses){
    const cell=cells.get(key(Math.round(t.x),Math.round(t.z)));
    if(cell&&t.level===0)doorways.set(cell.id,t);
  }
  scenery=[...tiles.map(t=>({t,building:false})),...orderedHouses.map(t=>({t,building:true}))].sort((a,b)=>a.t.z-b.t.z||a.t.h-b.t.h);
  undo.disabled=!history.length;if(bg)backdrop();
}
function houseShape(t){
  return {floor:blockHeight,h:blockHeight,floors:1,width:1,offset:0,base:.06,tall:false};
}
function blockPalette(t){
  const warmth=Math.max(0,Math.min(1,.5+(t.seed-.5)*.85));
  const aged=Math.max(0,Math.min(1,.28+t.level*.14+noise(t.x,t.z,21)*.32));
  return {
    wall:mix('#e8d2b2','#f2e6d2',warmth*.55),
    wallShade:mix('#c8ab88','#d7bea2',warmth*.65),
    plasterWash:'rgba(132,96,76,'+(0.10+aged*0.16)+')',
    roof:mix('#af5c3d','#cf7a4c',warmth),
    roofDark:mix('#7e452e','#965339',warmth),
    ridge:mix('#db9a64','#efbd84',warmth*.8),
    stone:mix('#b69d7f','#d2bea0',warmth*.7),
    stoneDark:mix('#8f775f','#a58c72',warmth*.75),
    trim:mix('#7f5945','#9a7156',warmth*.75)
  };
}

function blockGeometry(t){
  const origin=P(t.x,t.z,t.h),point=(u,v,y)=> {
    const p=P(t.x+(u-.5)*.64+(v-.5)*.48,t.z+(u-.5)*.23-(v-.5)*.52,t.h+y);
    return [(p[0]-origin[0])/S,(p[1]-origin[1])/S];
  };
  const bottom=[[0,0],[1,0],[1,1],[0,1]].map(([u,v])=>point(u,v,-.06));
  const top=[[0,0],[1,0],[1,1],[0,1]].map(([u,v])=>point(u,v,blockHeight));
  return {bottom,top,point};
}
// These relationships are derived at render time. They never create history
// entries, so all architectural decoration remains subordinate to one tap.
function roofEdge(t,du,dv){
  const other=adjacentBlock(t,du,dv);
  if(!other)return 'eave';
  return adjacentBlock(other,0,0,1)?'abutment':'continuous';
}
function roofPlan(t){
  const sides=[[0,-1],[1,0],[0,1],[-1,0]];
  return sides.map(([du,dv])=>roofEdge(t,du,dv));
}
function blockSupport(t){
  if(t.level===0)return {kind:'bearing',clearance:0};
  if(adjacentBlock(t,0,0,-1))return {kind:'bearing',clearance:0};
  // One arcade supports a whole column. A floating storey stacked directly
  // above an existing floating one does not produce intersecting columns.
  const below=orderedHouses.filter(b=>Math.abs(b.x-t.x)<1e-4&&Math.abs(b.z-t.z)<1e-4&&b.h<t.h-.001);
  if(below.length)return {kind:'upper-extension',clearance:0};
  const terrain=height(t.x,t.z);
  return {kind:'arcade',clearance:Math.max(.06,t.h-.06-terrain)};
}
function drawArcade(g,t,point,palette=blockPalette(t)){
  // Support posts are tied to the block's corners, unlike the old pair of
  // frontal strokes. Their feet follow the local slope independently.
  // No building is added below, so upper extensions remain freely undoable.
  const corners=[[.10,.10],[.90,.10],[.90,.90],[.10,.90]];
  for(const [u,v] of corners){
    const wx=t.x+(u-.5)*.64+(v-.5)*.48;
    const wz=t.z+(u-.5)*.23-(v-.5)*.52;
    const terrain=height(wx,wz);
    const foot=Math.min(-.12,terrain-t.h-.045);
    const half=.043;
    const front=[point(u-half,v-half,-.055),point(u+half,v-half,-.055),point(u+half,v-half,foot),point(u-half,v-half,foot)];
    const side=[point(u+half,v-half,-.055),point(u+half,v+half,-.055),point(u+half,v+half,foot),point(u+half,v-half,foot)];
    poly(g,front,palette.stone);paintedPlane(g,'limestone',front,.80);
    poly(g,side,palette.stoneDark);paintedPlane(g,'limestone',side,.58);
    line(g,...front[0],...front[3],palette.trim,.012);
  }
  // Two lintels make the underside read as a supported gallery, whether
  // viewed from the main street or from the side.
  for(const [a,b,c,d] of [
    [[.055,.055],[.945,.055],[.945,.055],[.055,.055]],
    [[.945,.055],[.945,.945],[.945,.945],[.945,.055]]
  ]){
    const beam=[point(...a,-.035),point(...b,-.035),point(...c,-.135),point(...d,-.135)];
    poly(g,beam,palette.stoneDark);
    line(g,...beam[0],...beam[1],palette.ridge,.017);
  }
}
function renderBlock(g,t){
  const {bottom,top,point}=blockGeometry(t);
  const joinU=adjacentBlock(t,1,0),joinV=adjacentBlock(t,0,-1),above=adjacentBlock(t,0,0,1);
  const connected=[adjacentBlock(t,-1,0),joinU,joinV,adjacentBlock(t,0,1)].some(Boolean);
  const faces=[];
  const palette=blockPalette(t);
  const support=blockSupport(t);
  if(support.kind==='arcade')drawArcade(g,t,point,palette);
  function wall(indices,du,dv,shade){
    const [a,b]=indices;
    const quad=[top[a],top[b],bottom[b],bottom[a]];
    const next=adjacentBlock(t,du,dv);
    if(next)return;
    const nearbyPath=[...objects].some(([id,type])=>{
      const cell=cells.get(id);return type==='path'&&cell&&Math.hypot(cell.x-t.x,cell.z-t.z)<1.6;
    });
    const material=t.level>0?'upper-bay':nearbyPath?'entrance-bay':connected?'arcade-bay':'entrance-bay';
    poly(g,quad,palette.wall);paintedPlane(g,material,quad,.97);
    poly(g,quad,palette.plasterWash);
    if(shade)poly(g,quad,'#3525394c');
    line(g,...bottom[a],...bottom[b],palette.wallShade,.022);
    line(g,...top[a],...bottom[a],'rgba(116,83,64,.22)',.01);
    line(g,...top[b],...bottom[b],'rgba(255,245,229,.10)',.006);
    if(!above){line(g,...top[a],...top[b],palette.trim,.027)}
    faces.push({t,type:'side',du,dv,points:quad});
  }
  wall([0,1],0,-1,false);
  wall([1,2],1,0,true);
  if(!above){
    poly(g,top,palette.roof);
    paintedPlane(g,'tiles',[top[3],top[2],top[1],top[0]],.95);
    poly(g,top,'rgba(90,38,18,.05)');
    // Roof edges are context-sensitive: a matching roof flows through,
    // a taller neighbor receives a recessed flashing strip, and only a
    // genuinely exterior edge gets a raised terracotta coping.
    const edges=roofPlan(t);
    for(const [i,[a,b,du,dv]] of [[0,1,0,-1],[1,2,1,0],[2,3,0,1],[3,0,-1,0]].entries()){
      const kind=edges[i];
      if(kind==='continuous'){
        // Quiet tile joint. No competing parapets across a shared roof.
        line(g,...top[a],...top[b],'rgba(123,85,64,.14)',.006);
      }else if(kind==='abutment'){
        // Dark tile-to-wall flashing avoids a bright roof ledge apparently
        // terminating inside the taller adjoining volume.
        line(g,...top[a],...top[b],palette.roofDark,.041);
        line(g,...top[a],...top[b],palette.ridge,.014);
      }else{
        const A=point([0,1,1,0][a],[0,0,1,1][a],blockHeight+.036);
        const B=point([0,1,1,0][b],[0,0,1,1][b],blockHeight+.036);
        line(g,...top[a],...top[b],palette.roof,.038);
        line(g,...A,...B,palette.roofDark,.033);
        line(g,...top[a],...top[b],palette.ridge,.012);
      }
    }
    faces.push({t,type:'top',points:top});
    // A taller neighbour casts a narrow strip onto the lower terrace.
    if(joinU&&adjacentBlock(joinU,0,0,1))poly(g,[top[1],top[2],point(.83,1,blockHeight),point(.83,0,blockHeight)],'#42332c55');
    if(joinV&&adjacentBlock(joinV,0,0,1))poly(g,[top[0],top[1],point(1,.16,blockHeight),point(0,.16,blockHeight)],'#42332c55');
  }
  if(t.level===0){
    // Exposed blocks meet the slope with an individually sized stone footing.
    for(const [a,b,du,dv] of [[0,1,0,-1],[1,2,1,0]]){
      if(adjacentBlock(t,du,dv))continue;
      const depth=Math.min(.30,Math.max(.06,t.h-height(t.x,t.z)+.08));
      const foot=[bottom[a],bottom[b],[bottom[b][0],bottom[b][1]+depth],[bottom[a][0],bottom[a][1]+depth]];
      poly(g,foot,palette.stone);paintedPlane(g,'limestone',foot,.92);
    }
  }
  return faces;
}
function house(g,t){
  const faces=renderBlock(g,t),[x,y]=P(t.x,t.z,t.h);
  if(!t.free)for(const face of faces)blockFaces.push({...face,points:face.points.map(([u,v])=>[x+S*u,y+S*v])});
}
function houseAt(x,y){
  for(let i=blockFaces.length-1;i>=0;i--)if(insideFace(x,y,blockFaces[i].points))return blockFaces[i];
  return null;
}
function snappedBlock(site){
  let best=null,distance=.43;
  for(const t of orderedHouses){
    if(t.level!==0)continue;
    const dx=site.x-t.x,dz=site.z-t.z,det=-.4432;
    const u=Math.round((-.52*dx-.48*dz)/det),v=Math.round((-.23*dx+.64*dz)/det);
    if(Math.abs(u)+Math.abs(v)>2)continue;
    const candidate=blockOffset(t,u,v);
    const d=Math.hypot(candidate.x-site.x,candidate.z-site.z);
    if(d<distance){distance=d;best=candidate}
  }
  return best||{...site,level:0};
}
function addBlock(site){
  let candidate={...site};
  // If the target already has a block, add exactly one above that column.
  while(blockIndex.has(blockKey(candidate.x,candidate.z,candidate.h))){
    candidate.h+=blockHeight;candidate.level=(candidate.level||0)+1;
  }
  const id='block:'+crypto.randomUUID();
  history.push([{id,type:'block',x:candidate.x,z:candidate.z,h:candidate.h,level:candidate.level||0,group:candidate.group||id}]);
  // The builder should not unexpectedly pan when placing or undoing one
  // block. Camera motion belongs to the player's gestures and Explore.
  rebuild();born.set(id,performance.now());save();chime();
  hint.textContent='One block added · roof to raise · wall to extend';
}
function alterHouse(hit){
  addBlock(hit.type==='top'?blockOffset(hit.t,0,0,1):blockOffset(hit.t,hit.du,hit.dv));
}
function placeHouse(t){addBlock(snappedBlock(t))}
