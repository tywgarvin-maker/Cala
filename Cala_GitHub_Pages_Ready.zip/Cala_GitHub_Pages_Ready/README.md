# Cala — browser playable development build

Cala is an early Roman creative-city-building prototype, inspired by effortless block-by-block building. Its current version experiments with derived boulevards, U-shaped entrance courts, and peristyle gardens. It does **not** yet include living citizens or walk mode.

## Publish with GitHub Pages (one-time setup)

1. Create a public GitHub repository named `cala` under your account. Initialize it with a README.
2. Upload the contents of this folder **to the repository root** (not nested inside another folder), replacing the starter README if requested. The root should contain `index.html`, `cala.js`, `blocks.js`, `emergent.js`, `painting.js`, `art/`, and `.nojekyll`.
3. Open the repository's **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.
4. After GitHub Pages reports successful deployment, open `https://YOUR-USERNAME.github.io/cala/` in Safari. The exact URL depends on your GitHub username and repository name.
5. For future versions, update the same repository. GitHub Pages will automatically publish the new commit.

The site is static: no dependencies, login, server, or build tool required.

## Current caveats

- This is an independent prototype, not Astra's live Cala Version 8.
- Local browser saves from the old ChatGPT site do **not** automatically transfer between domains. The new site starts a separate town.
- This source has passed geometry and construction logic tests, but could not be interactively browser-tested in the current tool environment (browser navigation was blocked). Treat the first Safari test as the real runtime gate.
- Desktop: click and drag for paths/trees; click on a roof to grow vertically, on a visible wall to extend; use Examples to inspect generated spaces.
- The visual result is still an early 2D Canvas prototype.
