// All painted surfaces follow the same world-space geometry used for picking.
const art={};
function loadPainting(ready){
  return Promise.all(['entrance-bay','arcade-bay','upper-bay','side-bay','campanian-bay','headland','scrub','plaster','tiles','limestone','cypress','olive','door','window'].map(name=>new Promise(resolve=>{
    const img=new Image();
    img.onload=()=>{art[name]=img;resolve()};
    img.onerror=resolve;
    img.src='art/'+name+'.webp';
  }))).then(ready);
}
function paintedPlane(g,name,quad,alpha=1){
  const img=art[name];if(!img)return;
  g.save();g.globalAlpha*=alpha;
  // Two triangles allow the texture to follow sloped ground and tapering roof panels.
  for(const ids of [[0,1,3],[2,3,1]]){
    const [origin,right,down]=ids.map(i=>quad[i]);
    g.save();g.beginPath();g.moveTo(...origin);g.lineTo(...right);g.lineTo(...down);g.closePath();g.clip();
    g.transform(right[0]-origin[0],right[1]-origin[1],down[0]-origin[0],down[1]-origin[1],...origin);
    if(ids[0]===2){g.translate(1,1);g.scale(-1,-1)}
    g.drawImage(img,0,0,1,1);g.restore();
  }
  g.restore();
}
function terrainPaint(g,t,pts,S){
  if(!art.scrub)return;
  g.save();g.beginPath();pts.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.clip();
  const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]),w=S*5.6,h=S*2.7;
  g.globalAlpha*=land(t.x,t.z)<.16?.23:.81;
  for(let y=Math.floor(Math.min(...ys)/h)*h;y<Math.max(...ys);y+=h)
    for(let x=Math.floor(Math.min(...xs)/w)*w;x<Math.max(...xs);x+=w)g.drawImage(art.scrub,x,y,w+.2,h+.2);
  g.restore();
}
function paintTerraces(g){
  // Low garden retaining walls follow broken stretches of contour above the shore.
  for(const [x0,z0,count,curve] of [[-5.5,1.5,9,-.10],[-2.8,2.55,8,.10],[2.3,1.75,8,-.09],[-3.2,-.55,7,-.10]]){
    for(let i=0;i<count;i++){
      const segment=u=>{let x=x0+u*.34,z=z0+curve*u+.12*Math.sin(u*.46);return P(x,z,height(x,z))};
      const a=segment(i),b=segment(i+1),rise=S*.135;
      const face=[[a[0],a[1]-rise],[b[0],b[1]-rise],b,a];
      poly(g,face,'#ac8f6c');paintedPlane(g,'limestone',face,.92);
      line(g,...face[0],...face[1],'#ebca94',S*.031);
    }
  }
}
