/* Cala — Emergent Roman Architecture 01
   Pure pattern recognition over independent blocks. Architectural responses
   are derived; they never enter history, affect saves, or consume a block tap. */
'use strict';
const AX=.64, AZ=.23, BX=.48, BZ=-.52;
(function (root) {
  const DET=AX*BZ-BX*AZ;
  const directions=[[[1,0],[0,1]], [[0,1],[-1,0]], [[-1,0],[0,-1]], [[0,-1],[1,0]]];
  const coord=(a,b)=>a+','+b;
  function analyzeRomanPatterns(blocks){
    const ground=blocks.filter(b=>b.level===0);
    if(!ground.length)return [];
    // Different foundations need not share a lattice. Evaluate each coherent
    // lattice only once; nearby free placements can coexist without snapping.
    const remaining=ground.slice(),lattices=[];
    while(remaining.length){
      const anchor=remaining.shift(),positions=new Map(),matched=[anchor];
      positions.set('0,0',anchor);
      for(let n=remaining.length-1;n>=0;n--){
        const b=remaining[n],dx=b.x-anchor.x,dz=b.z-anchor.z;
        const u=(dx*BZ-dz*BX)/DET,v=(dz*AX-dx*AZ)/DET;
        if(Math.abs(u-Math.round(u))<.035&&Math.abs(v-Math.round(v))<.035){
          const k=coord(Math.round(u),Math.round(v));
          if(!positions.has(k)){positions.set(k,b);matched.push(b)}
          remaining.splice(n,1);
        }
      }
      lattices.push({anchor,positions});
    }
    const features=[];
    for(const lattice of lattices){
      const {positions:pos}=lattice,has=(u,v)=>pos.has(coord(u,v));
      if(pos.size<6)continue;
      const points=[...pos.keys()].map(k=>k.split(',').map(Number));
      const minU=Math.min(...points.map(p=>p[0])),maxU=Math.max(...points.map(p=>p[0]));
      const minV=Math.min(...points.map(p=>p[1])),maxV=Math.max(...points.map(p=>p[1]));
      const candidate=[];
      // An enclosed, roofless center is a Roman garden/peristyle seed.
      for(let size=8;size>=4;size--)for(let u=minU;u<=maxU-size+1;u++)for(let v=minV;v<=maxV-size+1;v++){
        let ok=true;
        for(let a=0;a<size&&ok;a++)for(let b=0;b<size;b++){
          const boundary=a===0||b===0||a===size-1||b===size-1;
          if(has(u+a,v+b)!==boundary){ok=false;break}
        }
        if(ok)candidate.push({type:'garden',u,v,size,area:size*size,axis:0,anchor:lattice.anchor});
      }
      // Three wings around an open court. Require a real opening across the
      // full front, not a hollow that happens to resemble a U in projection.
      for(const [[au,av],[bu,bv]] of directions){
        const world=(u,v,i,j)=>[u+i*au+j*bu,v+i*av+j*bv];
        for(const [u,v] of points)for(let w=3;w<=7;w++)for(let d=3;d<=7;d++){
          let ok=true;
          for(let i=0;i<w&&ok;i++)for(let j=0;j<d;j++){
            const [x,y]=world(u,v,i,j),rim=j===0||i===0||i===w-1;
            if(has(x,y)!==rim){ok=false;break}
          }
          if(!ok)continue;
          for(let i=0;i<w;i++){const [x,y]=world(u,v,i,d);if(has(x,y))ok=false}
          if(ok)candidate.push({type:'entrance',u,v,w,d,au,av,bu,bv,area:w*d,anchor:lattice.anchor});
        }
      }
      // Paired street fronts separated by 1–3 clear blocks; the largest
      // uninterrupted segment is the formal boulevard, never a player asset.
      for(const [[au,av],[bu,bv]] of directions.slice(0,2))for(const [u,v] of points){
        for(let gap=1;gap<=3;gap++){
          let len=0;
          while(len<60){
            const x=u+len*au,y=v+len*av;
            if(!has(x,y)||!has(x+(gap+1)*bu,y+(gap+1)*bv))break;
            let clear=true;
            for(let s=1;s<=gap;s++)if(has(x+s*bu,y+s*bv)){clear=false;break}
            if(!clear)break;len++;
          }
          if(len>=3){
            const before=has(u-au,v-av)&&has(u-au+(gap+1)*bu,v-av+(gap+1)*bv);
            if(!before)candidate.push({type:'boulevard',u,v,len,gap,au,av,bu,bv,area:len*(gap+2),anchor:lattice.anchor});
          }
        }
      }
      // Favor the complete composition over incidental subsets. Keep only
      // one reading when the same open footprint has competing interpretations.
      const ordered=candidate.sort((a,b)=>a.type===b.type?b.area-a.area:({garden:0,entrance:1,boulevard:2}[a.type]-{garden:0,entrance:1,boulevard:2}[b.type]));
      const claimed=new Set();
      function interior(c){
        const out=[];
        if(c.type==='garden')for(let i=1;i<c.size-1;i++)for(let j=1;j<c.size-1;j++)out.push(coord(c.u+i,c.v+j));
        if(c.type==='entrance')for(let i=1;i<c.w-1;i++)for(let j=1;j<c.d;j++)out.push(coord(c.u+i*c.au+j*c.bu,c.v+i*c.av+j*c.bv));
        if(c.type==='boulevard')for(let i=0;i<c.len;i++)for(let j=1;j<=c.gap;j++)out.push(coord(c.u+i*c.au+j*c.bu,c.v+i*c.av+j*c.bv));
        return out;
      }
      for(const c of ordered){
        const tiles=interior(c);
        if(tiles.some(k=>claimed.has(k)))continue;
        if(features.filter(f=>f.anchor===lattice.anchor).length>=6)break;
        tiles.forEach(k=>claimed.add(k));
        features.push({...c,tiles});
      }
    }
    return features;
  }
  root.analyzeRomanPatterns=analyzeRomanPatterns;
  if(typeof module!=='undefined'&&module.exports)module.exports={analyzeRomanPatterns};
})(globalThis);

let romanSpaces=[];
function refreshRomanSpaces(){romanSpaces=analyzeRomanPatterns([...houses.values()]);
  const status=document.getElementById('spaces');
  if(status){const counts=romanSpaces.reduce((s,p)=>(s[p.type]=(s[p.type]||0)+1,s),{});
    status.textContent=romanSpaces.length?[
      counts.boulevard?`${counts.boulevard} boulevard${counts.boulevard>1?'s':''}`:'',
      counts.entrance?`${counts.entrance} entrance court${counts.entrance>1?'s':''}`:'',
      counts.garden?`${counts.garden} garden${counts.garden>1?'s':''}`:''].filter(Boolean).join(' · '):'Build something beautiful';
  }
}
const calaRebuild=typeof rebuild!=='undefined'?rebuild:null;
if(calaRebuild)rebuild=function(){calaRebuild();refreshRomanSpaces()};
function spaceWorld(f,u,v){return [f.anchor.x+u*AX+v*BX,f.anchor.z+u*AZ+v*BZ]}
function spacePoint(f,u,v,lift=.028){const [x,z]=spaceWorld(f,u,v);return P(x,z,Math.max(height(x,z),f.anchor.h-.05)+lift)}
function spaceTile(g,f,u,v,tone){
  const p=[[u-.5,v-.5],[u+.5,v-.5],[u+.5,v+.5],[u-.5,v+.5]].map(([a,b])=>spacePoint(f,a,b));
  poly(g,p,tone);
  g.strokeStyle='rgba(255,250,234,.32)';g.lineWidth=Math.max(.5,S*.008);
  g.beginPath();g.moveTo(...p[0]);p.slice(1).forEach(q=>g.lineTo(...q));g.closePath();g.stroke();
  return p;
}
function spaceEllipse(g,x,y,rx,ry,color){g.beginPath();g.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),0,0,Math.PI*2);g.fillStyle=color;g.fill()}
function drawRomanGarden(g,f){
  for(let i=1;i<f.size-1;i++)for(let j=1;j<f.size-1;j++){
    const edge=i===1||j===1||i===f.size-2||j===f.size-2;
    const p=spaceTile(g,f,f.u+i,f.v+j,edge?'#c6b7a0':'#86946a');
    if(!edge){const c=spacePoint(f,f.u+i,f.v+j,.045);spaceEllipse(g,c[0],c[1],S*.11,S*.049,'#536e4d');
      for(let k=0;k<3;k++)spaceEllipse(g,c[0]+(k-1)*S*.07,c[1]-S*.028,S*.048,S*.029,['#779663','#607c50','#95a777'][k]);}
  }
  const center=spacePoint(f,f.u+(f.size-1)/2,f.v+(f.size-1)/2,.12);
  spaceEllipse(g,center[0]+S*.025,center[1]+S*.082,S*.29,S*.135,'rgba(44,48,36,.22)');
  spaceEllipse(g,center[0],center[1],S*.27,S*.125,'#c1b39a');
  spaceEllipse(g,center[0],center[1]-S*.027,S*.225,S*.097,'#7aadb0');
  spaceEllipse(g,center[0],center[1]-S*.034,S*.10,S*.041,'#a9d1cb');
  // Architectural piers around the court imply the future peristyle system.
  for(let i=1;i<f.size-1;i+=Math.max(1,Math.floor((f.size-2)/3)))for(let side of [1,f.size-2]){
    const c=spacePoint(f,f.u+i,f.v+side,.09);spaceEllipse(g,c[0],c[1],S*.045,S*.02,'#aa9278');
    line(g,c[0],c[1],c[0],c[1]-S*.17,'#ddcbb3',Math.max(2,S*.035));
    spaceEllipse(g,c[0],c[1]-S*.17,S*.043,S*.017,'#f2e5d4');
  }
}
function drawRomanEntrance(g,f){
  for(let i=1;i<f.w-1;i++)for(let j=1;j<f.d;j++){
    const u=f.u+i*f.au+j*f.bu,v=f.v+i*f.av+j*f.bv;
    spaceTile(g,f,u,v,(i+j)%3===0?'#d5c1a8':'#d1bca2');
  }
  // A formal axial procession and small planting on either side.
  const middle=(f.w-1)/2;
  for(let j=1;j<f.d;j++){
    const c=spacePoint(f,f.u+middle*f.au+j*f.bu,f.v+middle*f.av+j*f.bv,.08);
    spaceEllipse(g,c[0],c[1],S*.078,S*.034,'#eee1c9');
  }
  for(let j=1;j<f.d;j+=2)for(let i of [1,f.w-2]){
    if(Math.abs(i-middle)<.4)continue;
    const c=spacePoint(f,f.u+i*f.au+j*f.bu,f.v+i*f.av+j*f.bv,.09);
    spaceEllipse(g,c[0],c[1],S*.16,S*.067,'#b4ad91');
    spaceEllipse(g,c[0],c[1]-S*.03,S*.105,S*.048,'#6f8b5e');
  }
}
function drawRomanBoulevard(g,f){
  for(let i=0;i<f.len;i++)for(let j=1;j<=f.gap;j++){
    const u=f.u+i*f.au+j*f.bu,v=f.v+i*f.av+j*f.bv;
    spaceTile(g,f,u,v,(i+j)%4===0?'#d4c4ab':'#c7b8a0');
  }
  // Longitudinal paving rhythm and planted intervals keep a formal street
  // reading even when the neighboring buildings have irregular rooflines.
  for(let i=0;i<f.len;i++){
    const c=spacePoint(f,f.u+i*f.au+(.5+f.gap/2)*f.bu,f.v+i*f.av+(.5+f.gap/2)*f.bv,.075);
    spaceEllipse(g,c[0],c[1],S*.065,S*.028,'#e7d9c0');
    if(i%2===1&&f.gap>=2){for(const edge of [1,f.gap]){
      const p=spacePoint(f,f.u+i*f.au+edge*f.bu,f.v+i*f.av+edge*f.bv,.08);
      spaceEllipse(g,p[0],p[1],S*.16,S*.08,'#a6a88a');
      spaceEllipse(g,p[0],p[1]-S*.035,S*.11,S*.052,'#5f8060');
    }}
  }
}
function spaceDepth(f){
  if(!f.tiles.length)return f.anchor.z;
  return f.tiles.reduce((sum,k)=>{const [u,v]=k.split(',').map(Number);return sum+spaceWorld(f,u,v)[1]},0)/f.tiles.length;
}
function drawRomanSpaces(g,features=romanSpaces){
  if(!features.length)return;
  g.save();
  for(const f of features){
    if(f.type==='garden')drawRomanGarden(g,f);
    else if(f.type==='entrance')drawRomanEntrance(g,f);
    else if(f.type==='boulevard')drawRomanBoulevard(g,f);
  }
  g.restore();
}
// Demo mode never writes to the user's persistent settlement.
let demoSnapshot=null;
const calaSave=typeof save!=='undefined'?save:null;
if(calaSave)save=function(){if(!demoSnapshot)calaSave()};
function demoBlock(anchor,u,v){return {x:anchor.x+u*AX+v*BX,z:anchor.z+u*AZ+v*BZ,h:anchor.h,level:0}}
function sampleRomanPattern(which){
  if(!demoSnapshot)demoSnapshot={history:JSON.parse(JSON.stringify(history)),camera:{...camera}};
  history=[];
  const anchor={x:0,z:0,h:height(0,0)};
  const coords=[];
  if(which==='garden')for(let i=-2;i<=3;i++)for(let j=-2;j<=3;j++)if(i===-2||i===3||j===-2||j===3)coords.push([i,j]);
  if(which==='entrance')for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++)if(j===-2||i===-2||i===2)coords.push([i,j]);
  if(which==='boulevard')for(let i=-3;i<=3;i++)for(let j of [-2,2])coords.push([i,j]);
  for(const [u,v] of coords){const b=demoBlock(anchor,u,v),id='demo:'+which+':'+u+','+v;history.push([{...b,id,type:'block',group:'demo:'+which}])}
  if(which==='entrance')for(const [u,v] of [[-2,-2],[2,-2]]){const b=demoBlock(anchor,u,v);history.push([{...b,h:b.h+blockHeight,level:1,id:'demo:tower:'+u+','+v,type:'block',group:'demo:entrance'}])}
  rebuild();born.clear();
  // Frame the example at building scale instead of the entire coastline.
  camera.zoom=2.25;
  const focus=P(anchor.x,anchor.z,anchor.h+blockHeight*.55);
  camera.x=W*.50-camera.zoom*focus[0];
  camera.y=H*.50-camera.zoom*focus[1];
  draw();
  const labels={garden:'Enclosed peristyle garden',entrance:'U-shaped entrance court',boulevard:'Roman boulevard'};
  hint.textContent=labels[which]+' · every wall is an editable block';
  document.getElementById('return-town').hidden=false;
  document.getElementById('examples').hidden=true;
  document.getElementById('examples-button').setAttribute('aria-expanded','false');
}
function returnToTown(){
  if(!demoSnapshot)return;
  history=demoSnapshot.history;Object.assign(camera,demoSnapshot.camera);demoSnapshot=null;rebuild();born.clear();draw();
  document.getElementById('return-town').hidden=true;
  hint.textContent='Tap to build · geometry creates Roman spaces';
}
if(typeof document!=='undefined')document.getElementById('examples-button').addEventListener('click',()=>{
  const panel=document.getElementById('examples');panel.hidden=!panel.hidden;
  document.getElementById('examples-button').setAttribute('aria-expanded',String(!panel.hidden));
});
if(typeof document!=='undefined')document.querySelectorAll('[data-pattern]').forEach(b=>b.addEventListener('click',()=>sampleRomanPattern(b.dataset.pattern)));
if(typeof document!=='undefined')document.getElementById('return-town').addEventListener('click',returnToTown);
